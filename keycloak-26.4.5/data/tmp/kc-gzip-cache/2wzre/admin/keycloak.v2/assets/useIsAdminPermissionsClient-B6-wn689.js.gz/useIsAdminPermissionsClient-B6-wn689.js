import{useState as m,useEffect as t}from"react";import{d as o}from"./main-CEQTdNHa.js";function f(i){const{realmRepresentation:s}=o(),[n,e]=m(!1);return t(()=>{s?.adminPermissionsClient?e(i===s.adminPermissionsClient.id):e(!1)},[i,s]),n}export{f as u};
//# sourceMappingURL=useIsAdminPermissionsClient-B6-wn689.js.map
