import{c as s}from"./main-CEQTdNHa.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-COctGaoa.js.map
