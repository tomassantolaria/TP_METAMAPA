import{cg as o}from"./main-CEQTdNHa.js";const e=t=>r=>r&&o(t,r)||"—";export{e as t};
//# sourceMappingURL=translationFormatter-DL7Fihos.js.map
